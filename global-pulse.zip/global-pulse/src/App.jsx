import React, { useState, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { TrendingUp, TrendingDown, Activity, Info, ChevronDown, ChevronUp } from "lucide-react";

// Demo-Datensatz – illustrativ, keine Live-Daten, keine Anlageberatung
const COUNTRIES = [
  { name: "Indien", code: "IN", region: "Asien", gdp: 6.5, inflation: 4.8, pmi: 58.5, rate: 6.5 },
  { name: "Vietnam", code: "VN", region: "Asien", gdp: 6.8, inflation: 3.4, pmi: 51.2, rate: 4.5 },
  { name: "Philippinen", code: "PH", region: "Asien", gdp: 5.9, inflation: 3.2, pmi: 53.0, rate: 5.5 },
  { name: "Indonesien", code: "ID", region: "Asien", gdp: 5.0, inflation: 2.9, pmi: 52.0, rate: 6.0 },
  { name: "China", code: "CN", region: "Asien", gdp: 4.8, inflation: 0.6, pmi: 49.5, rate: 3.1 },
  { name: "Ägypten", code: "EG", region: "Afrika", gdp: 4.2, inflation: 18.5, pmi: 48.0, rate: 19.25 },
  { name: "Saudi-Arabien", code: "SA", region: "Naher Osten", gdp: 3.5, inflation: 1.8, pmi: 56.0, rate: 5.5 },
  { name: "Polen", code: "PL", region: "Europa", gdp: 3.4, inflation: 4.1, pmi: 50.5, rate: 5.75 },
  { name: "Nigeria", code: "NG", region: "Afrika", gdp: 3.2, inflation: 22.0, pmi: 51.5, rate: 27.5 },
  { name: "Türkei", code: "TR", region: "Europa", gdp: 3.0, inflation: 38.0, pmi: 47.0, rate: 45.0 },
  { name: "USA", code: "US", region: "Nordamerika", gdp: 2.3, inflation: 2.7, pmi: 50.2, rate: 4.5 },
  { name: "Südkorea", code: "KR", region: "Asien", gdp: 2.0, inflation: 1.9, pmi: 50.0, rate: 2.75 },
  { name: "Brasilien", code: "BR", region: "Südamerika", gdp: 2.1, inflation: 4.3, pmi: 49.0, rate: 10.5 },
  { name: "Mexiko", code: "MX", region: "Nordamerika", gdp: 1.8, inflation: 4.0, pmi: 48.5, rate: 9.5 },
  { name: "UK", code: "GB", region: "Europa", gdp: 1.2, inflation: 2.6, pmi: 50.8, rate: 4.25 },
  { name: "Südafrika", code: "ZA", region: "Afrika", gdp: 1.1, inflation: 4.5, pmi: 49.8, rate: 7.5 },
  { name: "Japan", code: "JP", region: "Asien", gdp: 0.9, inflation: 2.2, pmi: 49.0, rate: 0.5 },
  { name: "Frankreich", code: "FR", region: "Europa", gdp: 0.8, inflation: 1.9, pmi: 47.5, rate: 3.15 },
  { name: "Deutschland", code: "DE", region: "Europa", gdp: 0.4, inflation: 2.3, pmi: 45.5, rate: 3.15 },
  { name: "Russland", code: "RU", region: "Europa", gdp: -1.0, inflation: 9.2, pmi: 47.0, rate: 19.0 },
];

// ETF-Mapping – reale Produktnamen als Beispiele, TER/Verfügbarkeit vor Investition beim Anbieter prüfen
const ETF_MAP = {
  IN: { access: "voll", etfs: [{ name: "iShares MSCI India UCITS ETF", ticker: "IIND", ter: "0,65%" }] },
  VN: { access: "eingeschränkt", note: "Kein reines Einzelland-UCITS-ETF verfügbar.", etfs: [{ name: "Xtrackers MSCI AC Asia ex Japan Swap UCITS ETF", ticker: "XMAJ", ter: "0,65%" }] },
  PH: { access: "eingeschränkt", note: "Kein reines Einzelland-UCITS-ETF verfügbar.", etfs: [{ name: "iShares MSCI Philippines ETF", ticker: "EPHE", ter: "0,59%" }] },
  ID: { access: "voll", etfs: [{ name: "Xtrackers MSCI Indonesia Swap UCITS ETF", ticker: "XCID", ter: "0,65%" }] },
  CN: { access: "voll", etfs: [{ name: "iShares MSCI China UCITS ETF", ticker: "ICHN", ter: "0,40%" }] },
  EG: { access: "eingeschränkt", note: "Kein UCITS-Einzelland-ETF, nur US-gelistete Alternative.", etfs: [{ name: "VanEck Egypt Index ETF", ticker: "EGPT", ter: "0,85%" }] },
  SA: { access: "voll", etfs: [{ name: "iShares MSCI Saudi Arabia Capped UCITS ETF", ticker: "SASX", ter: "0,60%" }] },
  PL: { access: "voll", etfs: [{ name: "iShares MSCI Poland UCITS ETF", ticker: "IPOL", ter: "0,74%" }] },
  NG: { access: "eingeschränkt", note: "Kein Einzelland-ETF, nur über Frontier-Market-Produkte abgedeckt.", etfs: [{ name: "iShares MSCI Frontier and Select EM ETF", ticker: "FM", ter: "0,79%" }] },
  TR: { access: "voll", etfs: [{ name: "iShares MSCI Turkey UCITS ETF", ticker: "ITKY", ter: "0,74%" }] },
  US: { access: "voll", etfs: [{ name: "iShares Core S&P 500 UCITS ETF", ticker: "CSPX", ter: "0,07%" }] },
  KR: { access: "voll", etfs: [{ name: "iShares MSCI Korea UCITS ETF", ticker: "IKOR", ter: "0,74%" }] },
  BR: { access: "voll", etfs: [{ name: "iShares MSCI Brazil UCITS ETF", ticker: "IBZL", ter: "0,74%" }] },
  MX: { access: "voll", etfs: [{ name: "iShares MSCI Mexico Capped UCITS ETF", ticker: "IMXC", ter: "0,65%" }] },
  GB: { access: "voll", etfs: [{ name: "iShares Core FTSE 100 UCITS ETF", ticker: "ISF", ter: "0,07%" }] },
  ZA: { access: "voll", etfs: [{ name: "iShares MSCI South Africa UCITS ETF", ticker: "IZAF", ter: "0,65%" }] },
  JP: { access: "voll", etfs: [{ name: "iShares Core MSCI Japan IMI UCITS ETF", ticker: "SJPA", ter: "0,15%" }] },
  FR: { access: "voll", etfs: [{ name: "Amundi CAC 40 UCITS ETF", ticker: "CAC", ter: "0,25%" }] },
  DE: { access: "voll", etfs: [{ name: "iShares Core DAX UCITS ETF", ticker: "EXS1", ter: "0,16%" }] },
  RU: { access: "gesperrt", note: "Seit den Sanktionen 2022 ausgesetzt bzw. liquidiert – über reguläre UCITS-ETFs aktuell nicht investierbar.", etfs: [] },
};

const ACCESS_STYLE = {
  voll: { label: "Voll zugänglich", color: "#E8A33D" },
  eingeschränkt: { label: "Eingeschränkt", color: "#9CA3AF" },
  gesperrt: { label: "Gesperrt/Sanktioniert", color: "#B0413E" },
};

export default function GlobalPulse() {
  const [metric, setMetric] = useState("momentum");
  const [selected, setSelected] = useState("IN");
  const [inflationFactor, setInflationFactor] = useState(0.25);
  const [showFormula, setShowFormula] = useState(false);

  const METRICS = {
    momentum: {
      label: "Momentum-Score",
      unit: "pt",
      get: (c) => +(c.gdp - c.inflation * inflationFactor).toFixed(1),
      neutral: 0,
      betterHigh: true,
    },
    gdp: { label: "BIP-Wachstum", unit: "%", get: (c) => c.gdp, neutral: 0, betterHigh: true },
    pmi: { label: "Einkaufsmanagerindex (PMI)", unit: "", get: (c) => c.pmi, neutral: 50, betterHigh: true },
    inflation: { label: "Inflation", unit: "%", get: (c) => c.inflation, neutral: 5, betterHigh: false },
    rate: { label: "Leitzins", unit: "%", get: (c) => c.rate, neutral: null, betterHigh: null },
  };

  const m = METRICS[metric];

  const data = useMemo(
    () =>
      [...COUNTRIES]
        .map((c) => ({ ...c, value: m.get(c) }))
        .sort((a, b) => b.value - a.value),
    [metric]
  );

  const avg = (data.reduce((s, c) => s + c.value, 0) / data.length).toFixed(1);
  const top = data[0];
  const bottom = data[data.length - 1];
  const selectedCountry = data.find((d) => d.code === selected) || top;
  const etfInfo = ETF_MAP[selectedCountry.code];
  const accessStyle = ACCESS_STYLE[etfInfo.access];

  return (
    <div
      style={{ fontFamily: "'IBM Plex Mono', monospace" }}
      className="min-h-screen bg-[#0B0D10] text-[#E5E2D9] p-4 md:p-8"
    >
      <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&display=swap"
      />

      {/* Header */}
      <div className="max-w-5xl mx-auto mb-8 border-b border-[#2A2E35] pb-5 flex items-end justify-between flex-wrap gap-3">
        <div>
          <div className="text-xs tracking-[0.3em] text-[#E8A33D] mb-2">
            GLOBAL PULSE — TERMINAL V0.1
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
            Welt-Konjunktur, sortiert nach Wachstumsdynamik
          </h1>
        </div>
        <div className="text-xs text-[#6B7280] text-right">
          STAND: DEMO-DATEN
          <br />
          20 LÄNDER · 5 KENNZAHLEN
        </div>
      </div>

      {/* Metric toggle */}
      <div className="max-w-5xl mx-auto flex flex-wrap gap-2 mb-3">
        {Object.entries(METRICS).map(([key, def]) => (
          <button
            key={key}
            onClick={() => setMetric(key)}
            className={`px-4 py-2 text-sm border transition-colors ${
              metric === key
                ? "bg-[#E8A33D] text-[#0B0D10] border-[#E8A33D] font-semibold"
                : "border-[#2A2E35] text-[#9CA3AF] hover:border-[#E8A33D] hover:text-[#E8A33D]"
            }`}
          >
            {def.label}
          </button>
        ))}
      </div>

      {/* Formel-Panel – nur sichtbar wenn Momentum aktiv */}
      {metric === "momentum" && (
        <div className="max-w-5xl mx-auto mb-6 border border-[#E8A33D22] bg-[#14171C]">
          <button
            onClick={() => setShowFormula(!showFormula)}
            className="w-full flex items-center justify-between px-4 py-3 text-xs text-[#E8A33D] hover:bg-[#1E2128] transition-colors"
          >
            <span className="tracking-widest">WIE WIRD DER MOMENTUM-SCORE BERECHNET?</span>
            {showFormula ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>

          {showFormula && (
            <div className="px-4 pb-4 border-t border-[#2A2E35]">
              <div className="mt-4 mb-4 text-center text-sm font-semibold tracking-wide">
                <span className="text-[#E8A33D]">Momentum-Score</span>
                <span className="text-[#6B7280] mx-2">=</span>
                <span className="text-[#E5E2D9]">BIP-Wachstum</span>
                <span className="text-[#6B7280] mx-2">−</span>
                <span className="text-[#4F7CAC]">{inflationFactor.toFixed(2)}</span>
                <span className="text-[#6B7280] mx-2">×</span>
                <span className="text-[#E5E2D9]">Inflation</span>
              </div>

              <div className="grid md:grid-cols-3 gap-3 mb-4 text-xs">
                <div className="border border-[#2A2E35] p-3">
                  <div className="text-[#E8A33D] mb-1">BIP-Wachstum</div>
                  <p className="text-[#9CA3AF] leading-relaxed">Wie stark wächst die Wirtschaft? Trägt voll zum Score bei – Wachstum ist das primäre Signal.</p>
                </div>
                <div className="border border-[#2A2E35] p-3">
                  <div className="text-[#4F7CAC] mb-1">Inflations-Faktor ({inflationFactor.toFixed(2)})</div>
                  <p className="text-[#9CA3AF] leading-relaxed">Wie stark bestraft Inflation den Score? Niedrig = Wachstum zählt mehr. Hoch = Preisstabilität wird strenger bewertet.</p>
                </div>
                <div className="border border-[#2A2E35] p-3">
                  <div className="text-[#9CA3AF] mb-1">Warum nicht 1:1?</div>
                  <p className="text-[#9CA3AF] leading-relaxed">Hohes Wachstum bei moderater Inflation ist oft noch attraktiv. Ein 1:1-Abzug würde Schwellenmärkte systematisch benachteiligen.</p>
                </div>
              </div>

              {/* Slider */}
              <div className="border border-[#2A2E35] p-3">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-[#6B7280]">Inflations-Gewichtung anpassen</span>
                  <span className="text-[#E8A33D] font-semibold">{inflationFactor.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="1.0"
                  step="0.05"
                  value={inflationFactor}
                  onChange={(e) => setInflationFactor(parseFloat(e.target.value))}
                  className="w-full accent-[#E8A33D]"
                />
                <div className="flex justify-between text-[10px] text-[#6B7280] mt-1">
                  <span>0.05 – Inflation fast ignoriert</span>
                  <span>1.0 – Inflation voll gewichtet</span>
                </div>
                <p className="text-[10px] text-[#6B7280] mt-2">
                  ⚡ Der Score im Chart aktualisiert sich live. Dies ist eine experimentelle Formel – kein anerkannter Finanzindex.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Stat cards */}
      <div className="max-w-5xl mx-auto grid grid-cols-3 gap-3 mb-8">
        <StatCard
          icon={<TrendingUp size={14} />}
          label="Spitzenreiter"
          value={`${top.name} · ${top.value}${m.unit}`}
          accent="#E8A33D"
        />
        <StatCard
          icon={<Activity size={14} />}
          label="Durchschnitt (20 Länder)"
          value={`${avg}${m.unit}`}
          accent="#E5E2D9"
        />
        <StatCard
          icon={<TrendingDown size={14} />}
          label="Schlusslicht"
          value={`${bottom.name} · ${bottom.value}${m.unit}`}
          accent="#4F7CAC"
        />
      </div>

      {/* Chart */}
      <div className="max-w-5xl mx-auto border border-[#2A2E35] bg-[#14171C] p-4 md:p-6">
        <div className="text-xs text-[#6B7280] mb-3">
          Klick auf ein Land, um passende ETFs zu sehen →
        </div>
        <ResponsiveContainer width="100%" height={560}>
          <BarChart data={data} layout="vertical" margin={{ left: 10, right: 30 }}>
            <XAxis
              type="number"
              stroke="#6B7280"
              tick={{ fill: "#6B7280", fontSize: 11 }}
              tickFormatter={(v) => `${v}${m.unit}`}
            />
            <YAxis
              type="category"
              dataKey="name"
              stroke="#6B7280"
              tick={{ fill: "#E5E2D9", fontSize: 12 }}
              width={110}
            />
            <Tooltip
              contentStyle={{
                background: "#0B0D10",
                border: "1px solid #2A2E35",
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 12,
              }}
              formatter={(v) => [`${v}${m.unit}`, m.label]}
            />
            <Bar dataKey="value" radius={[0, 2, 2, 0]}>
              {data.map((entry, i) => {
                const range = Math.max(...data.map((d) => Math.abs(d.value - (m.neutral ?? 0)))) || 1;
                const opacity = 0.5 + 0.5 * (Math.abs(entry.value - (m.neutral ?? 0)) / range);
                let fill = "#9CA3AF"; // neutral/informativ (z. B. Leitzins ohne gut/schlecht-Wertung)
                if (m.neutral !== null) {
                  const good = m.betterHigh ? entry.value >= m.neutral : entry.value <= m.neutral;
                  fill = good ? "#E8A33D" : "#4F7CAC";
                }
                return (
                  <Cell
                    key={i}
                    fill={fill}
                    fillOpacity={opacity}
                    stroke={entry.code === selected ? "#E5E2D9" : "none"}
                    strokeWidth={entry.code === selected ? 1.5 : 0}
                    style={{ cursor: "pointer" }}
                    onClick={() => setSelected(entry.code)}
                  />
                );
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* ETF-Mapping Panel */}
      <div className="max-w-5xl mx-auto mt-4 border border-[#2A2E35] bg-[#14171C] p-4 md:p-6">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div>
            <div className="text-xs tracking-[0.3em] text-[#E8A33D] mb-1">ETF-ZUGANG</div>
            <h2 className="text-lg font-semibold">{selectedCountry.name}</h2>
          </div>
          <div
            className="text-xs px-3 py-1 border"
            style={{ color: accessStyle.color, borderColor: accessStyle.color }}
          >
            {accessStyle.label}
          </div>
        </div>

        {etfInfo.note && (
          <p className="text-xs text-[#9CA3AF] mb-3 leading-relaxed">{etfInfo.note}</p>
        )}

        {etfInfo.etfs.length > 0 ? (
          <div>
            {etfInfo.etfs.map((e) => (
              <div
                key={e.ticker}
                className="flex items-center justify-between border-t border-[#2A2E35] py-2 first:border-t-0 first:pt-0"
              >
                <div className="text-sm">{e.name}</div>
                <div className="text-xs text-[#6B7280]">
                  {e.ticker} · TER {e.ter}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-[#B0413E]">Aktuell kein investierbares ETF-Produkt.</p>
        )}
      </div>

      {/* Footer / disclaimer */}
      <div className="max-w-5xl mx-auto mt-6 flex items-start gap-2 text-xs text-[#6B7280] leading-relaxed">
        <Info size={14} className="mt-0.5 shrink-0" />
        <p>
          Momentum-Score = BIP-Wachstum − 0,25 × Inflation (frei gewählte Demo-Formel, kein
          etablierter Index). PMI {'>'} 50 = Expansion, {'<'} 50 = Kontraktion. Amber = günstige
          Ausprägung, Blau = ungünstige; Leitzins ist rein informativ ohne Wertung. ETF-Angaben
          sind reale Produktbeispiele zur Illustration, keine Kauf- oder Anlageempfehlung – TER,
          Verfügbarkeit und Eignung bitte vor jeder Investition selbst prüfen. Alle Werte sind
          illustrative Beispieldaten, keine Live-Daten aus IWF/Weltbank.
        </p>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, accent }) {
  return (
    <div className="border border-[#2A2E35] bg-[#14171C] p-4">
      <div className="flex items-center gap-2 text-[10px] tracking-wider text-[#6B7280] mb-2">
        {icon}
        {label.toUpperCase()}
      </div>
      <div className="text-sm md:text-base font-semibold" style={{ color: accent }}>
        {value}
      </div>
    </div>
  );
}
