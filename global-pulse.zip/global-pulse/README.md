# Global Pulse

ETF-Investor Dashboard – Welt-Konjunktur auf einen Blick.

## Deploy-Anleitung (5 Minuten)

### Schritt 1 – GitHub Repository erstellen
1. Gehe zu https://github.com/new
2. Repository-Name: `global-pulse`
3. Auf "Create repository" klicken

### Schritt 2 – Dateien hochladen
1. Im neuen Repository auf "uploading an existing file" klicken
2. Alle Dateien aus diesem Ordner hochladen (Struktur beibehalten)
3. "Commit changes" klicken

### Schritt 3 – Vercel verbinden
1. Gehe zu https://vercel.com
2. "Continue with GitHub" – mit deinem GitHub Account einloggen
3. "Add New Project" → dein `global-pulse` Repository auswählen
4. Einmal "Deploy" klicken – fertig

Deine URL lautet dann: `global-pulse.vercel.app`
